//Daniel Lambert
//djlamber
//This program takes in a set of x,y points and through 3 different heuristics calculates the shortest path through a set of points.

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

// Constants that define the method to use when adding points to the tour
#define INSERT_FRONT      0
#define NEAREST_NEIGHBOR  1
#define SMALLEST_INCREASE 2

// Node of a linked list that stores (x, y) location of points.
// You should NOT need to modify this.
typedef struct node
{
   double x;            // x-coordinate of this point in the tour
   double y;            // y-coordinate of this point in the tour
   struct node* next;   // Pointer to the next node in the linked list
} Node;

// Function prototypes, you should NOT need to modify these.
Node* addFront(Node* first, double x, double y);
void printNode(Node* node);
void printTour(Node* first);
int tourSize(Node* first);
double distance(Node* a, Node* b);
double tourDistance(Node* first);
void freeTour(Node* first);
Node* addNearestNeighbor(Node* first, double x, double y);
Node* addSmallestIncrease(Node* first, double x, double y);

// Add a new point to the front of the tour.
// Passed a pointer to the first node in the tour, NULL if creating a new tour.
// Returns pointer to the first node in the linked list after the addition.
Node* addFront(Node* first, double x, double y)
{
  Node* nFirst = malloc(sizeof(Node));
  nFirst->x = x;
  nFirst->y = y;
  if(first != NULL){
    nFirst->next = first;
  }
  return nFirst;
}

// Print out the point stored at the given node.
// Round to 4 decimal places and output a line feed (\n), e.g.:
// (1.2345, 6.7890)
void printNode(Node* node)
{
  printf("(%.4f, %.4f)\n", node->x, node->y);
}

// Print out all the points in the tour from first to last.
// Passed a pointer to the first node in the tour.
// If the first is NULL, doesn't print anything.
void printTour(Node* first)
{
  if(first != NULL){
    Node* current = first;
    printNode(current);
    while(current->next != NULL){
      printNode(current->next);
      current = current->next;
    }
  }
}

// Get the number of points in the tour.
// Passed a pointer to the first node in the tour.
// If first is NULL, return a size of 0.
int tourSize(Node* first)
{
  if(first == NULL){
    return 0;
  }
  int count = 1;
  Node* current = first;
  while(current->next != NULL){
    count = count + 1;
    current = current->next;
  }
  return count;
}

// Calculate the Euclidean distance between two nodes.
// You can assume both a and b are both not NULL.
double distance(Node* a, Node* b)
{
  double distance = sqrt((a->x-b->x)*(a->x-b->x)+(a->y-b->y)*(a->y-b->y));
  return distance;
}

// Calculate the total distance between all points in the tour.
// Since the tour is circular, this includes the distance from the last point back to the start.
// Passed a pointer to the first node in the tour.
// If first is NULL, return a tour length of 0.0.
double tourDistance(Node* first)
{
  if(first == NULL){
    return 0.0;
  }
  double totalDist = 0.0; 
  Node* current = first;
  while(current->next != NULL){
    totalDist += distance(current, current->next);
    current = current->next;
  }
  totalDist += distance(current, first);
  return totalDist;
}

// Add a new point after the point that it is closest to.
// If there is a tie, insert it after the first such point you find.
// Passed a pointer to the first node in the tour, NULL if creating a new tour.
// Returns pointer to the first node in the linked list after the addition.
Node* addNearestNeighbor(Node* first, double x, double y)
{
  Node* newNode = malloc(sizeof(Node));
  newNode->x = x;
  newNode->y = y;
  if(first != NULL){
    Node* current = first;
    Node* closestNode = current;
    double currentDist = 0.0;
    double closestDist = DBL_MAX;
    //figures out closest node
    while(current != NULL){
      currentDist = distance(newNode, current);
      if(currentDist < closestDist){
	closestNode = current;
	closestDist = currentDist; 
      }
      current = current->next;
    }
    //adds node after closest node
    Node* temp = closestNode->next;
    closestNode->next = newNode;
    newNode->next = temp;
 }else {
    first = newNode;
  }
  return first;
}

// Add a new point after the point where it results in the least increase in tour length.
// If there is a tie, insert it after the first such point you find.
// Passed a pointer to the first node in the tour, NULL if creating a new tour.
// Returns pointer to the first node in the linked list after the addition.
Node* addSmallestIncrease(Node* first, double x, double y)
{
  Node* newNode = malloc(sizeof(Node));
  newNode->x = x;
  newNode->y = y;
  if(first != NULL){
    Node* current = first;
    Node* closestNode = current;
    double origLen;
    double newLen;
    double smallestIncrease = DBL_MAX;
    //figures out shortest length node
    while(current->next != NULL){
      origLen = distance(current, current->next); 
      newLen = distance(current, newNode) + distance(newNode, current->next);
      if(newLen - origLen < smallestIncrease){
	smallestIncrease = newLen - origLen;
	closestNode = current;
      }
      current = current->next;
    }
    //checks last to first
    origLen = distance(current, first);
    newLen = distance(current, newNode) + distance(newNode, first);
    if(newLen - origLen < smallestIncrease){
      smallestIncrease = newLen - origLen;
      closestNode = current;
    }
    //adds node after shortest length node
    Node* temp = closestNode->next;
    closestNode->next = newNode;
    newNode->next = temp;
    }else {
    first = newNode;
  }
  return first;
}

// Deallocate all the memory of the Node structures in the linked list.
// Passed a pointer to the first node in the tour.
// If first is NULL, don't do anything.
void freeTour(Node* first)
{
  if(first != NULL){
    Node* current = first;
    Node* temp;
    while(current->next != NULL){
      temp = current;
      current = temp->next;
      free(temp);
    }
  }
}

// Main function, you should NOT need to modify this.
// You may want to comment it out temporarily and insert your own test code during development.
int main(int argc, char** argv)
{
   // Default to inserting nodes right after the first node
   int heuristic = INSERT_FRONT;

   // If we get a command line argument it is setting the heurstic
   if (argc > 1)
      heuristic = atoi(argv[1]);

   // Start with an empty linked list
   Node* first = NULL;

   // Variables for reading in the next point from standard input
   double x = 0.0;
   double y = 0.0;

   // Read in points until we run out of data
   while (scanf("%lf %lf", &x, &y) == 2)
   {
      // Add the point to the linked list according to the heursitic set by the command line arg
      if (heuristic == INSERT_FRONT)
         first = addFront(first, x, y);
      else if (heuristic == NEAREST_NEIGHBOR)
         first = addNearestNeighbor(first, x, y);
      else if (heuristic == SMALLEST_INCREASE)
         first = addSmallestIncrease(first, x, y);
      else
      {
         printf("Invalid heuristic of %d!\n", heuristic);
         return 1;
      }
   }

   printTour(first);
   printf("Tour distance = %.4f\n", tourDistance(first));
   printf("Number of points = %d\n", tourSize(first));

   freeTour(first);
   first = NULL;

   return 0;
}
