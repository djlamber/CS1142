//Daniel Lambert  
//djlamber            
//This file implements the key data type

#include "Key.h"

bool initKey(Key* key, const char* filename){
  key->size = 0;
  key->pos = 0;
  key->data = malloc(0);
  FILE* f = fopen(filename, "r");
  if(f == NULL){
    printf("Failed to load key file: %s\n", filename);
    return false;
  }
  char c;
  while(fscanf(f,"%c",&c) > 0){
      key->size += 1;
      key->data = realloc(key->data, key->size);
      key->data[key->pos] = c;
     key->pos += 1;
  }
  key->pos = 0;
  fclose(f);
  return true;
}

void freeKey(Key* key){
  free(key->data);
}

char applyKey(Key* key, Stats* stats, char ch, bool debug){
  char ciphCh = key->data[key->pos];
  char newCh = ciphCh ^ ch;
  updateStats(stats, newCh);
  key->pos += 1;
  if(key->pos == key->size){
    key->pos = 0;
  }
  char retCh = newCh;
  if(debug == true){
    unsigned int ICh = (unsigned char)ch;
    if(ch < 32 || ch > 126){
      ch = '~';
    }
    unsigned int ICiphCh = (unsigned char)ciphCh;
    if(ciphCh < 32 ||ciphCh > 126){
      ciphCh = '~';
    }
    unsigned int INewCh = (unsigned char)newCh;
    if(newCh < 32 ||newCh > 126){
      newCh = '~';
    }
    printf("%3u '%c' ^ %3u '%c' -> %3u '%c'\n", ICh, ch, ICiphCh, ciphCh, INewCh, newCh);
  }
  return retCh;
}
