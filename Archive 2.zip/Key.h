//Daniel Lambert 
//djlamber           
//This is a header file for the functions/data type related to the key

#ifndef KEY_H_
#define KEY_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "Stats.h"

typedef struct Key
{
  char* data;  // Stores the actual data for this Key
  int size;   // How many bytes of memory this Key can store
  int pos;    // Current character to use next for encoding/decoding
} Key;

bool initKey(Key* key, const char* filename);                // Initialize and load from the given filename, returns false if loading of key failed
void freeKey(Key* key);                                      // Deallocate any memory used by key
char applyKey(Key* key, Stats* stats, char ch, bool debug);  // Process ch using the current position in the key, advance key, update stats, optionally print debug line, returns output character.


#endif 
