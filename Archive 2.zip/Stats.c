//Daniel Lambert  
//djlamber
//This file implements the stats data type

#include "Stats.h"

void initStats(Stats* stats){
  stats->letters = 0; 
  stats->spaces = 0;
  stats->numbers = 0; 
  stats->other = 0;
}

void updateStats(Stats* stats, char ch){
  if((ch > 64 && ch < 91)||( ch > 96 && ch < 123)){
    stats->letters += 1;
  }
  else if(ch == 32){
    stats->spaces += 1;
  }
  else if(ch > 47 && ch <58){
    stats->numbers += 1;
  }
  else{
    stats->other += 1;
  }
}

void printStats(Stats* stats){
  int total = stats->letters + stats->spaces + stats->numbers + stats->other;
  printf("Output %d characters: %.2f%% letters, %.2f%% spaces, %.2f%% numbers, %.2f%% other\n", total, stats->letters*100/((double)total), stats->spaces*100/((double)total), stats->numbers*100/((double)total), stats->other*100/((double)total));
}
