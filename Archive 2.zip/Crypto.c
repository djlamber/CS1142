//Daniel Lambert
//djlamber
//This program encrypts and decrypts a text file based on a given cipher

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "Stats.h"
#include "Key.h"


int main(int argc,char* argv[])
{
  if(argc >= 4){
    bool debug = false;
    if(argc >= 5){
      if(atoi(argv[4]) != 0){
	debug = true;
      }
    }
    char* inputF = argv[1];
    char* outputF = argv[2];
    const char* keyF = argv[3];
    FILE* iF = fopen(inputF, "r");
    if(iF == NULL){
      printf("Failed to open input file: %s\n", inputF);
      return 0;
    }
    FILE* oF = fopen(outputF, "w");
    if(oF == NULL){
      printf("Failed to open output file: %s\n", outputF);
      return 0;
    }
    struct Key* CKey = malloc(0);
    bool init = initKey(CKey, keyF);
    if(init == false){
      return 0;
    }
    struct Stats* CStats = malloc(0);
    initStats(CStats);

    char c = NULL;
    char nC = NULL;
    while(fscanf(iF,"%c",&c) > 0){
      nC = applyKey(CKey, CStats, c, debug);
      fputc(nC, oF);
    }
    fclose(iF);
    fclose(oF);
    printStats(CStats);
    freeKey(CKey);

  }else{
    printf("Crypto <input file> <output file> <key file> [debug] \n");
  }
  return 0;
}
