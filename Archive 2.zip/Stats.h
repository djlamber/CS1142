//Daniel Lambert  
//djlamber
//This is a header file for the functions/data type related to keeping track of the stats of thet encryption/decryption output

#ifndef STATS_H_
#define STATS_H_

#include <stdio.h>
#include <stdlib.h>

typedef struct Stats
{
  int letters;   // Count of letter characters in the output file
  int spaces;  // Count of space characters in the output file
  int numbers;  // Count of number characters in the output file
  int other;   // Count of any chracters not a letter, space, or number
} Stats;

void initStats(Stats* stats);             // Initialize a stats structure
void updateStats(Stats* stats, char ch);  // Update stats based on ch output character
void printStats(Stats* stats);            // Print out statistics about the characters processed

#endif
