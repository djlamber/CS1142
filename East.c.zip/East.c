/*
Daniel Lambert
Djlamber
This program takes in a grid of elevation data and computes different things about it including minimum, maximum and average elevation and finds the shortest path.
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char** argv[]){
  int verbose = 0;
  if(argc>=2){
    verbose = atoi(argv[1]);
  }
  int ArrayX = 0;
  scanf("%d", &ArrayX);
  int ArrayY = 0;
  scanf("%d", &ArrayY);
  int Grid[ArrayX][ArrayY];
  int points = ArrayX*ArrayY;

  int min = INT_MAX;
  int max = -INT_MAX;
  double avg = 0;

  int xi = 0;
  int yi = 0;
  //Reads in data to 2D array
  while(yi < ArrayY){
    while(xi < ArrayX){
      int temp = 0;
      scanf("%d", &temp);
      if (temp < min){
	min = temp;
      }
      if (temp > max){
	max = temp;
      }
      avg = avg + (double)temp;
      Grid[xi][yi] = temp;
      xi = xi + 1;
    }
    yi = yi + 1;
    xi = 0;
  }
  //Prints out first set of Data
  avg = avg/points;
  printf("Data points: %d\n",points);
  printf("Avg elevation: %.2f\n",avg);
  printf("Min elevation: %d\n",min);
  printf("Max elevation: %d\n",max);
  //Calculates Greedy Algorithm
  int Greedy[ArrayY];
  int i = 0;
  while(i<ArrayY){
    int cost = 0;
    xi=0;
    yi=i;
    while(xi<ArrayX-1){
      int upper = 0;
      int mid = 0;
      int lower = 0;
      int temp = 0;
      temp = Grid[xi][yi]-Grid[xi+1][yi];
      mid = abs(temp);
      if(yi==0){//if at top row
	upper = INT_MAX;
	temp = Grid[xi][yi]-Grid[xi+1][yi+1];
	lower = abs(temp);
      }
      else if(yi==ArrayY-1){//if at bottom row
	temp = Grid[xi][yi]-Grid[xi+1][yi-1];
	upper =abs(temp);
	lower = INT_MAX;
      }
      else{//if inbetween top and bottom rows
	temp = Grid[xi][yi]-Grid[xi+1][yi-1];
	upper = abs(temp);
	temp = Grid[xi][yi]-Grid[xi+1][yi+1];
	lower = abs(temp);
      }
      if(mid<=upper && mid<=lower){
	cost = cost+mid;
	if(verbose == 1){
	  printf("(%d,%d) %d F, ",xi,yi,Grid[xi][yi]);
	}
      }
      else if(lower<=upper && lower<=mid){
	cost = cost+lower;
	if(verbose ==1){
	  printf("(%d,%d) %d D, ",xi,yi,Grid[xi][yi]);
	}
	yi = yi+1;
      }
      else{
	cost = cost+upper;
	if(verbose ==1){
	  printf("(%d,%d) %d U, ",xi,yi,Grid[xi][yi]);
	}
	yi = yi-1;
      }
      xi = xi+1;
    }
    if(verbose ==1){
    printf("(%d,%d) %d, cost %d\n",xi,yi,Grid[xi][yi],cost);
    }
    Greedy[i] = cost;
    i=i+1;
  }
  int minPath = INT_MAX;
  int minRow = INT_MAX;
  //Calculate min path
  i=0;
  while(i<ArrayY){
    if(Greedy[i]<minPath){
      minPath = Greedy[i];
      minRow = i;
    }
    i=i+1;
  }
  printf("Best: row %d, cost %d\n", minRow, minPath);
}
