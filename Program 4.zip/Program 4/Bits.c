/*
  Daniel Lambert                          
  djlamber                                    
  Input a number N and counts to see how many times need to divide N by 2 to get it strictly less than 1                                       
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char** argv[])
{
  if(argc >=2){
    int var = atoi(argv[1]);
    int count = 0;
    if(var >=0){ 
      while(var >= 1){
	var = var/2;
	count++;
      }

      printf("%d\n", count);
    }
    else{
      printf("Illegal input\n");
    }
  }else{
    printf("Bits <integer N>\n"); 
  }
}
