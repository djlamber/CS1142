/*
  Daniel Lambert                                                  
  djlamber      
  Computes the distance between the centers of two circles and checks to see if they intersect or not
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char** argv[])
{
  if(argc >= 7){
    double x1 = atof(argv[1]);
    double y1 = atof(argv[2]);
    double r1 = atof(argv[3]);
    double x2 = atof(argv[4]);
    double y2 = atof(argv[5]);
    double r2 = atof(argv[6]);
    double d1 = x1-x2;
    double d2 = y1-y2;
    double dist = sqrt((d1*d1)+(d2*d2));
    double sumr = r1+r2;



    printf("Circle 1: (%.2f, %.2f) r = %.2f\n", x1, y1, r1);
    printf("Circle 2: (%.2f, %.2f) r = %.2f\n", x2, y2, r2);
    printf("Distance between centers = %.4f\n", dist);
    if(dist >= sumr){
      printf("%.4f >= %.4f, circles do not intersect\n", dist, sumr);
    }
    else{
      printf("%.4f < %.4f, circles intersect\n", dist, sumr);
    }
  }
  else{
    printf("TwoCircles <x1> <y1> <r1> <x2> <y2> <r2>\n");
  }
}
