/*
Daniel Lambert
djlamber
Takes in as input a greeting word and 3 names and outputs them.
 */
#include <stdio.h>
#include <stdlib.h>

int main(int argc,char** argv[])
{
  if(argc >= 5){
    printf("%s %s!\n",argv[1], argv[2]);
    printf("%s %s!\n",argv[1], argv[3]);
    printf("%s %s!\n",argv[1], argv[4]);
  }
  else{
    printf("Greetings <greeting> <name1> <name2> <name3>\n");
  }
}
